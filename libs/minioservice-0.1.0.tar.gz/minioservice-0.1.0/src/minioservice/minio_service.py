from io import BytesIO
from pathlib import Path

from minio import Minio
from minio.datatypes import Object


class MinioService:

    def __init__(self, minio_endpoint: str, access_key: str, secret_key: str, secure: bool = True):
        """
        Initializes the MinioService with the provided parameters.

        :param minio_endpoint: The endpoint (host:port) of the MinIO server.
        :param access_key: The access key for MinIO.
        :param secret_key: The secret key for MinIO.
        :param secure: Whether to use TLS (default is True).
        """
        self.client = Minio(
            endpoint=minio_endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure
        )

    def upload_file(self, bucket_name: str, object_name: str, data: BytesIO, content_size: int, mime_type: str | None = None, metadata: dict[str, str] | None = None) -> None:
        """
        Uploads a file (byte stream) to the specified MinIO bucket, creating the bucket if it doesn't exist.

        :param bucket_name: The name of the bucket to upload to.
        :param object_name: The name of the object in MinIO.
        :param data: A BytesIO object containing the file data to upload.
        :param content_size: The size of the content being uploaded in bytes.
        :param mime_type: The MIME type of the file being uploaded.
        :param metadata: Additional metadata (without 'X-Amz-Meta-' prefix).
        """
        if not self.client.bucket_exists(bucket_name=bucket_name):
            self.client.make_bucket(bucket_name=bucket_name)

        self.client.put_object(
            bucket_name=bucket_name,
            object_name=object_name,
            data=data,
            length=content_size,
            content_type=mime_type or "application/octet-stream",
            # MinIO will add 'X-Amz-Meta-' prefix to all metadata keys, so we can use simple keys here.
            metadata=metadata or {}  # ty: ignore[invalid-argument-type]
        )

    def download_file(self, bucket_name: str, object_name: str, local_path: Path | str) -> Path:
        """
        Downloads a file from the specified MinIO bucket to a local path.

        :param bucket_name: The name of the bucket to download from.
        :param object_name: The name of the object in MinIO.
        :param local_path: The local path where the file will be saved.
        :return: The path to the downloaded file.
        """
        path = Path(local_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.client.fget_object(
            bucket_name=bucket_name,
            object_name=object_name,
            file_path=str(local_path)
        )
        return path

    def get_file(self, bucket_name: str, object_name: str) -> BytesIO:
        """
        Retrieves a file from the specified MinIO bucket as a BytesIO object.

        :param bucket_name: The name of the bucket to retrieve from.
        :param object_name: The name of the object in MinIO.
        :return: A BytesIO object containing the file data.
        """
        response = self.client.get_object(
            bucket_name=bucket_name,
            object_name=object_name
        )
        data = BytesIO(response.read())
        response.close()
        response.release_conn()
        return data

    def list_files(self, bucket_name: str, prefix: str = "") -> list[Object]:
        """
        Lists files in the specified MinIO bucket with an optional prefix.
        :param bucket_name: The name of the bucket to list files from.
        :param prefix: An optional prefix to filter files (e.g., a folder path).
        :return: A list of objects in the bucket that match the prefix.
        """
        return list(self.client.list_objects(bucket_name=bucket_name, prefix=prefix, recursive=True))

    def get_latest_object(self, bucket_name: str, prefix: str = "") -> Object:
        """
        Retrieves the latest object from the specified MinIO bucket with an optional prefix.

        :param bucket_name: The name of the bucket to retrieve from.
        :param prefix: An optional prefix to filter files (e.g., a folder path).
        :return: The latest object in the bucket that matches the prefix.
        """
        objects = self.list_files(bucket_name=bucket_name, prefix=prefix)
        if not objects:
            raise FileNotFoundError(f"No files found in bucket '{bucket_name}' with prefix '{prefix}'.")

        return max(objects, key=lambda obj: obj.last_modified)

    def get_utf8_content(self, bucket_name: str, object_name: str) -> str:
        """
        Retrieves a file from the specified MinIO bucket and returns its content as a UTF-8 string.

        :param bucket_name: The name of the bucket to retrieve from.
        :param object_name: The name of the object in MinIO.
        :return: The content of the file as a UTF-8 string.
        """
        data = self.get_file(bucket_name, object_name)
        return data.getvalue().decode('utf-8')

    def __enter__(self):
        """
        Enables the use of the MinioService as a context manager.
        """
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """
        Ensures that resources are cleaned up when exiting the context manager.
        """
        # No explicit cleanup required yet, but kept here for completeness
        pass
