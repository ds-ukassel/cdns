# MinIO Service

Utility wrapper class for the python minio client providing some easy to use methods for common operations.

## Usage

```python
from minioservice import MinioService

# Initialize the MinIO service
minio_service = MinioService(
    minio_endpoint='play.min.io',
    access_key='abc',
    secret_key='xyz',
    secure=True
)

# Upload a file
minio_service.upload_file(
    bucket_name='my-bucket',
    object_name='path/to/object.txt',
    file_path='/local/path/to/file.txt'
)

# Get (the content of) the file
print(minio_service.get_utf8_content(bucket_name='my-bucket', object_name='path/to/object.txt'))
```
